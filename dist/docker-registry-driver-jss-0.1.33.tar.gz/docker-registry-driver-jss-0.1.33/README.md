# Docker registry jss storage driver

This is a [docker-registry backend driver][registry-core] for [jss Cloud Storage][jss].

## Usage (recommendation)

Go to [jss Cloud Storage](http://www.JAE.JD.com/) to get your access_key first.

Run docker-registry service by docker container

## Usage via pip

```
# Install pip
apt-get -y install python-pip

# finally
pip install jss docker-registry-driver-jss
